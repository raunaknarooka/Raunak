module.exports = {
    organization: 'raunaknarooka',
    username: 'raunak.narooka@lntinfotech.com',
    password: 'Raunak@456',
    environments: 'test'
}